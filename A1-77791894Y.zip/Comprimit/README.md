#Programació Modular

- Joan Molinas Ramon 77791894-Y

El document interseccio.h serveix per definir interseccions com es mostra a la clase capsa.
La idea era poder saber si hi havia intersecció i tornar l'objecte resultant.
